from django.apps import AppConfig


class InfostackappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'InfoStackApp'
